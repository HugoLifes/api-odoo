# -*- coding: utf-8 -*-
import json
from odoo import http
from odoo.http import request, Response
import xmlrpc.client

import base64
import json
import sys
import time

import requests

account_token = "009c218b08b5e1f5f0d6929daaf720e27b147c7c"  # Use your token
domain_name = "https://iap-extract.odoo.com"
path_to_pdf = 'addons/api-odoo/invocie_file/'

API_VERSION = 120  # Do not change
SUCCESS = 0
NOT_READY = 1


url ="http://localhost:8069"
db = "hugodb"
username ="admin"
password = "admin"

class ApiOdoo(http.Controller):
    @http.route('/api-odoo/api-odoo/',  auth='public',  method=['GET'], csrf=False)
    def index(self, **kw):
        try:
            pos_order = http.request.env['pos.order'].search([])
        except:
            return '<h1>Imposible Acceder al API</h1>'
        
        output = '<h1>Pos Order</h1><ul>'
        for sale in pos_order:
            output += '<li>' + sale['name'] + '</li>'
        output += '</ul>'
        return output
    

    @http.route("/api-odoo/get_id_orders/", auth="public", type="json", method=['GET'], cors='*', csrf=False)
    def getId(self, **kw):
        partners = http.request.env['res.partner'].sudo().search([])
        headers = {'Content-Type':'application/json'}
        body = {'results':{'code':200,'message':partners}}

        return Response(json.dumps(body), headers=headers)

    @http.route("/api-odoo/prueba/", type="json" ,auth="public",csrf=False, method=['GET', 'POST'] )
    def prueba(self, **kw):

        invoice_vals = []
        common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
        uid = common.authenticate(db,username,password,{})
        models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url))
        
        partner_id = models.execute_kw(db, uid, password,'res.partner', 'search', [[['is_company', '=', False]]], { 'limit':10})
        product_id = models.execute_kw(db, uid, password,'product.product', 'search', [[]], { 'limit':10})
        for partner in partner_id:
            invoice_val = {
                'partner_id': partner,
                'ref': 'Invoice created from XMLRP multiple invoice',
                'move_type': 'out_invoice'
            }
            invoice_line = []
            for product in product_id:
                invoice_line.append((0,0,{
                    'product_id': product,
                    'quantity':10,
                    'price_unit': 100
                }))
            invoice_val.update({'invoice_line_ids':invoice_line})  
            invoice_vals.append(invoice_val)
        # llamada que ejecuta las facturas
        invoice_id = models.execute_kw(db, uid, password, 'account.move', 'create', [invoice_vals])
        print(invoice_id)
        # llamada que ejecuta el boton post
        action_model = models.execute_kw(db, uid, password, 'account.move', 'action_post' , [50] )
        print(action_model)
        #llamada que ejecuta el boton send & print
        #action_model_send = models.execute_kw(db, uid, password, 'account.move', 'action_invoice_sent', [40] )
        
        #llamada que ejecuta registrar pago
        action_register_pay = models.execute_kw(db, uid, password, 'account.move', 'action_register_payment',[40])
        print(action_register_pay)
        return {
            'Status' : 200,
            'Message': 'La solicitud se ha procesado sin problemas'
        }
    
    @http.route('/api23/', auth='public', website=False, csrf=False, type='json', methods=['GET','POST'], cors='*')
    def search(self, **kw):
        order_val = []
        contact_list = []
        

        match kw["type_operation"]:
            case 1 :
                orderIdSearch(order_val, contact_list,**kw)
                print('datos por id compra')
            case 2 :
                orderRFCsearch(order_val, contact_list, **kw)
                print('Datos por rfc')
            case 3 :
                orderIDSocio(contact_list, order_val, **kw)
                print('Datos id socio')
       
        return contact_list
    
    #api que dice cuanto compro cada persona
    @http.route('/api/idOrder-Buyer/', auth='public', website=False, csrf=False, type='json', methods=['GET','POST'])
    def holi2(self, **kw):

        order = http.request.env['pos.order'].sudo().search([])
        partners = http.request.env['res.partner'].sudo().search([])
        company_ID = http.request.env['res.company'].sudo().search([('id', '=', kw['id'])])
        order_list = []
        print(company_ID.name)
        for orders in order:
            order_list.append({
                'id': orders.id,
                'name': orders.name,
                'user_id': orders.user_id.id,
                'company_id': orders.company_id.id,
                'comapany_name': company_ID.name
            })
        return order_list
    
    @http.route('/api2/', auth='public', website=False, csrf=False, type='json', methods=['GET','POST'])
    def holi(self, **kw):
        user_contact =  http.request.env['res.partner'].sudo().search([('id', '=', kw['id'])])
        user_contact.write({'name':kw['name']})
        #http.request.env['res.partner'].sudo().create({'name': kw['name']})
        return kw
    

    @http.route('/invoice/', auth='public', website=False, csrf=False, type='json', methods= ['GET','POST'] )
    def invoice(self, **kw):


        with open(path_to_pdf, "rb") as file:
            params = {
                'account_token': account_token,
                'version': API_VERSION,
                'documents': [base64.b64encode(file.read()).decode('ascii')],
            }

            response = jsonrpc("/iap/invoice_extract/parse", params)
            print("/parse call status: ", response['result']['status_msg'])

            if response['result']['status_code'] != SUCCESS:
                sys.exit(1)

            document_id = response['result']['document_id']
            params = {
                'version': API_VERSION,
                'document_ids': [document_id]
            }

            response = jsonrpc("/iap/invoice_extract/get_results", params)
            document_id = str(document_id)

            while response['result'][document_id]['status_code'] == NOT_READY:
                print("Procesando... intentando en 5 segungos")
                time.sleep(5)
                response = jsonrpc("/iap/invoice_extract/get_results", params)
            with open('results.txt','w') as outfile:
                json.dump(response, outfile, indent=2)
            print('\nResult saved in results.txt')

            if response['result'][document_id]['status_code'] != SUCCESS:
                print(response['result'][document_id]['status_code'])
                sys.exit(1)
            document_results = response['result'][document_id]['results'][0]
            print("\nTotal:", document_results['total']['selected_value']['content'])
            print("Subtotal:", document_results['subtotal']['selected_value']['content'])
            print("Invoice id:", document_results['invoice_id']['selected_value']['content'])
            print("Date:", document_results['date']['selected_value']['content'])
            print("...\n")

            params= {
                'document': document_id,
                'values':{
                    'total':{'content':100.0},
                    'subtotal':{'content':100.0},
                    'global_taxes':{'content':[]},
                    'global_taxes_amount':{'content': 0.0},
                    'date':{'content': '2020-09-25'},
                    'due_date':{'content': '2020-09-25'},
                    'invoice_id':{'content': document_results['invoice_id']['selected_value']['content']},
                    'partner':{'content': 'twinnta'},
                    'VAT_Number':{'content': 'BE23252248420'},
                    'currency':{'content': 'USD'},
                    'merged_lines':False,
                    'invoice_lines':{'lines': [{'description': 'Total TVA ',
                                     'quantity': 1.0,
                                     'unit_price': 100.0,
                                     'product': False,
                                     'taxes_amount': 0.0,
                                     'taxes': [],
                                     'subtotal': 100.0,
                                     'total': 100.0}]},

                }
            }
            response = jsonrpc("/iap/invoice_extract/validate", params)
            if response['result']['status_code'] == SUCCESS:
                print('/validate call status: Success')
                return "/validate call status: Success"
            else:
                print("/validate call status: wrong format")
                return "/validate call status: wrong format"
        

def orderIdSearch(order_val, contact_list,**kw):
    try:
        order = http.request.env['pos.order'].sudo().search([('pos_reference', '=', kw['id'])])
        partners = http.request.env['res.partner'].sudo().search([('id', '=',order.partner_id.id)])
    
        for orders in order:
            order_val.append({
                'id': orders.id,
                'name': orders.name,
                'user_id': orders.user_id.id,
                'date_order': orders.date_order,
                'socio_id': orders.partner_id.id,
                'pos_reference': orders.pos_reference,
                'amount_paid': orders.amount_paid,
                'amount_return': orders.amount_return,
                'state': orders.state,
                'create_date': orders.create_date,
        })
        for contact in partners:
            contact_list.append({
                'socio_id': contact.id,
                'name': contact.name,
                'email':contact.email,
                'phone': contact.phone,
                'commercial_company_name': contact.commercial_company_name,
                'RFC': contact.vat, 
                'order': order_val
        })
    except NameError:
        print(NameError)
        return {
            'ErrorType': 400,
            'Message': 'Un error ha ocurrido',
            'Posible_falla': 'No se encontro el dato'
        }
    return contact_list

def orderRFCsearch(order_val, contact_list, **kw):
    try:
        partners = http.request.env['res.partner'].sudo().search([('vat', '=', kw['id'])])
        order = http.request.env['pos.order'].sudo().search([('partner_id', '=', partners['id'])])

        for orders in order:
            order_val.append({
                'id': orders.id,
                'name': orders.name,
                'user_id': orders.user_id.id,
                'date_order': orders.date_order,
                'socio_id': orders.partner_id.id,
                'pos_reference': orders.pos_reference,
                'amount_paid': orders.amount_paid,
                'amount_return': orders.amount_return,
                'state': orders.state,
                'create_date': orders.create_date,
        })
        for contact in partners:
            contact_list.append({
                'socio_id': contact.id,
                'name': contact.name,
                'email':contact.email,
                'phone': contact.phone,
                'commercial_company_name': contact.commercial_company_name,
                'RFC': contact.vat, 
                'order': order_val
        })
    except NameError:
        print(NameError)
        return {
            'ErrorType': 400,
            'Message': 'Un error ha ocurrido',
            'Posible_falla': 'No se encontro el dato'
        }

    return contact_list

def orderIDSocio(contact_list, order_val, **kw):
    try:
        partners = http.request.env['res.partner'].sudo().search([('id', '=', kw['id'])])
        order = http.request.env['pos.order'].sudo().search([('partner_id', '=', partners['id'])])

        for orders in order:
         order_val.append({
            'id': orders.id,
            'name': orders.name,
            'user_id': orders.user_id.id,
            'date_order': orders.date_order,
            'socio_id': orders.partner_id.id,
            'pos_reference': orders.pos_reference,
            'amount_paid': orders.amount_paid,
            'amount_return': orders.amount_return,
            'state': orders.state,
            'create_date': orders.create_date,
        })
      
        for contact in partners:
            contact_list.append({
                'socio_id': contact.id,
                'name': contact.name,
                'email':contact.email,
                'phone': contact.phone,
                'commercial_company_name': contact.commercial_company_name,
                'RFC': contact.vat, 
                'order': order_val
        })
    except NameError:
        print(NameError)
        return {
            'ErrorType': 400,
            'Message': 'Un error ha ocurrido',
            'Posible_falla': 'No se encontro el dato'
        }
    return contact_list

def jsonrpc(path, params):
    payload = {
        'jsonrpc': '2.0',
        'method': 'call',
        'params': params,
        'id': 0,
    }
    req = requests.post(domain_name+path, json=payload, timeout=20)
    req.raise_for_status()
    resp = req.json()
    return resp